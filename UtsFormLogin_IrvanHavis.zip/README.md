# UtsFormLogin_IrvanHavis

Proyek Android Studio (Java, Android Views) dengan dua halaman: Profile dan Edit Profile.
Dibuat berdasarkan foto referensi pengguna. Nama profil ditulis **Jhon Lennon** sesuai permintaan, dengan foto asli John Lennon.
Palet: biru langit #0284C7, putih #FFFFFF, kuning pastel #FEF3C7.

## Cara membuka
1. Ekstrak UtsFormLogin_IrvanHavis.zip.
2. Android Studio → Open → pilih folder UtsFormLogin_IrvanHavis (yang berisi settings.gradle).
3. Gunakan Gradle JDK **21** atau **17** di Settings → Build, Execution, Deployment → Build Tools → Gradle. Jangan memakai JDK 25 untuk Gradle 8.13.
4. Pastikan Android SDK Platform 35 dan Build Tools 35.0.0 terpasang melalui SDK Manager.
5. Tunggu Gradle Sync. Koneksi internet diperlukan untuk pengunduhan awal Gradle dan komponen build.
6. Pilih emulator/HP Android 6.0 atau lebih baru, lalu klik Run.

## Fitur
- Foto profil bulat, cover, nama, bio, tombol Follow, statistik, pengikut, dan empat foto arsip.
- Edit nama, username, bio, kontak, dan gender.
- Ganti foto melalui pemilih foto sistem Android; tidak meminta akses seluruh galeri.
- Save Changes menyimpan data lokal, termasuk foto, walau aplikasi ditutup.
- Validasi nama kosong dan format username; konfirmasi saat membatalkan edit.
- Tombol Pesan menampilkan kontak; tombol bagikan membuka menu berbagi Android.
- Foto galeri dapat diketuk untuk diperbesar.
- Form edit dapat digulir agar tetap bisa dipakai pada layar kecil.

## Catatan
Nama berkas mengikuti permintaan UtsFormLogin_IrvanHavis. Cakupan aplikasinya adalah profil dan edit profil sesuai gambar; tidak ada login/server.
Statistik dan daftar pengikut adalah data contoh. Follow merupakan simulasi lokal.
Kontak awal kosong agar tidak mengarang alamat email/nomor telepon milik John Lennon.
Nama pengikut hanya contoh; ikon inisial bukan foto identitas mereka.
Tata letak mendekati gambar, dengan warna cerah pilihan pengguna.

## Struktur kode
- app/src/main/java/com/example/jhonlennonprofile/MainActivity.java: tampilan dan interaksi.
- app/src/main/res/layout/activity_main.xml: wadah halaman.
- app/src/main/res/values/styles.xml: tema aplikasi.
- app/src/main/res/drawable/: foto dan ikon.
- app/build.gradle: konfigurasi Android.
- CREDITS.md: sumber foto dan lisensi.

## Build dari terminal Windows
Pilih JAVA_HOME yang menunjuk JDK 17/21, kemudian:
```
gradlew.bat assembleDebug
gradlew.bat lintDebug
```
APK dihasilkan di app/build/outputs/apk/debug/app-debug.apk.

## Status pemeriksaan
- Kode Java berhasil dikompilasi dengan javac JDK 21 (target Java 17), Android API 35, dan stub R untuk pemeriksaan tipe/sintaks.
- Berkas XML diperiksa dapat dibaca dengan benar.
- Build APK dan Android Lint belum berhasil selesai: lingkungan pemeriksaan menolak akses penandatanganan debug dan proses AAPT2 gagal saat link resource.
- Belum diuji pada emulator atau HP. APK tidak disertakan.
- Gradle Wrapper 8.13 disertakan. Konfigurasi akhir menggunakan repositori resmi Google/Maven Central, tanpa jalur khusus komputer pembuat.
