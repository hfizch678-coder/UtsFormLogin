# Sumber foto
Foto disertakan sebagai aset lokal sehingga aplikasi tidak membutuhkan internet untuk menampilkannya.
Lisensi foto berikut tercatat sebagai CC0 1.0 pada Wikimedia Commons: https://creativecommons.org/publicdomain/zero/1.0/

- john_lennon.jpg: Eric Koch / Anefo, Nationaal Archief, 25 Maret 1969. Potongan disesuaikan DrMarvello82.
  https://commons.wikimedia.org/wiki/File:Bed-In_for_Peace,_Amsterdam_1969_-_John_Lennon_%26_Yoko_Ono_05_cropped.jpg
- archive_one.jpg: Joost Evers / Anefo, Nationaal Archief, 31 Maret 1969; potongan Waterborough.
  https://commons.wikimedia.org/wiki/File:John_Lennon_(1969).jpg
- archive_two.jpg: Eric Koch / Anefo, Nationaal Archief, 25 Maret 1969.
  https://commons.wikimedia.org/wiki/File:John_Lennon_en_zijn_echtgenote_Yoko_Ono_op_huwelijksreis_in_Amsterdam._John_Lenn,_Bestanddeelnr_922-2302.jpg
- archive_three.jpg: Eric Koch / Anefo, Nationaal Archief, 31 Maret 1969.
  https://commons.wikimedia.org/wiki/File:John_Lennon_en_echtgenote_Yoko_Ono_verlaten_het_Hilton_Hotel_te_Amsterdam,_Bestanddeelnr_922-2491.jpg

Cover ditampilkan dengan overlay biru. Foto dipotong saat ditampilkan melalui CENTER_CROP; file asli tetap disertakan.
