package com.example.jhonlennonprofile;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.*;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final int PURPLE = Color.rgb(2,132,199), INK = Color.rgb(37,34,44);
    private final int MUTED = Color.rgb(139,135,148);
    private FrameLayout root;
    private SharedPreferences prefs;
    private boolean editing = false;
    private String pendingPhoto = "";
    private EditText nameField, userField, bioField, contactField;
    private Spinner genderField;
    private ImageView editAvatar;
    private static final int PICK_PHOTO = 40;
    private static final String DEFAULT_BIO = "Musisi, penulis lagu, dan pendiri The Beatles.\nMusik, cinta, dan perdamaian.";
    private static final String[] GENDERS = {"Laki-laki", "Perempuan", "Tidak disebutkan"};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("profile", MODE_PRIVATE);
        setContentView(R.layout.activity_main);
        root = findViewById(R.id.root);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets;
        });
        root.requestApplyInsets();
        if (state != null && state.getBoolean("editing")) {
            pendingPhoto = state.getString("pendingPhoto", "");
            showEdit(false);
            nameField.setText(state.getString("name"));
            userField.setText(state.getString("username"));
            bioField.setText(state.getString("bio"));
            contactField.setText(state.getString("contact"));
            genderField.setSelection(state.getInt("gender"));
        } else showProfile();
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putBoolean("editing", editing);
        if (editing) {
            out.putString("pendingPhoto", pendingPhoto);
            out.putString("name", nameField.getText().toString());
            out.putString("username", userField.getText().toString());
            out.putString("bio", bioField.getText().toString());
            out.putString("contact", contactField.getText().toString());
            out.putInt("gender", genderField.getSelectedItemPosition());
        }
    }

    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setIncludeFontPadding(false); return t;
    }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private void gap(LinearLayout parent, int h) {
        parent.addView(new View(this), new LinearLayout.LayoutParams(1,dp(h)));
    }
    private void centered(LinearLayout parent, TextView t) {
        t.setGravity(Gravity.CENTER);
        parent.addView(t, new LinearLayout.LayoutParams(-1,-2));
    }
    private Button button(String label, boolean primary) {
        Button b = new Button(this); b.setText(label); b.setTextSize(14); b.setAllCaps(false);
        b.setTextColor(primary ? Color.WHITE : PURPLE);
        b.setBackground(bg(primary ? PURPLE : 0xfffef3c7, 5));
        b.setMinHeight(dp(48)); b.setMinimumHeight(dp(48));
        b.setPadding(dp(12),0,dp(12),0); return b;
    }
    private LinearLayout page() {
        root.removeAllViews();
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        scroll.setClipToPadding(false); scroll.setVerticalScrollBarEnabled(false);
        root.addView(scroll, new FrameLayout.LayoutParams(-1,-1));
        LinearLayout body = column(); body.setPadding(0,0,0,dp(28));
        scroll.addView(body); return body;
    }
    private void round(ImageView image) {
        image.setBackground(bg(0xffe0f2fe,100));
        image.setOutlineProvider(ViewOutlineProvider.BACKGROUND); image.setClipToOutline(true);
    }
    private ImageView photo(String path) {
        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setContentDescription("Foto John Lennon");
        loadPhoto(image, path); return image;
    }
    private void loadPhoto(ImageView image, String path) {
        Bitmap b = path.isEmpty() ? null : BitmapFactory.decodeFile(path);
        if (b != null) image.setImageBitmap(b); else image.setImageResource(R.drawable.john_lennon);
    }

    private void showProfile() {
        editing = false;
        LinearLayout page = page();
        FrameLayout hero = new FrameLayout(this);
        page.addView(hero, new LinearLayout.LayoutParams(-1,dp(232)));
        ImageView cover = photo("");
        cover.setImageResource(R.drawable.archive_two);
        cover.setColorFilter(0xff7dd3fc, android.graphics.PorterDuff.Mode.MULTIPLY);
        hero.addView(cover, new FrameLayout.LayoutParams(-1,dp(158)));
        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{0x990c4a6e,0x220ea5e9}));
        hero.addView(shade, new FrameLayout.LayoutParams(-1,dp(158)));
        TextView coverLabel = text("MUSIC  /  LOVE  /  PEACE",11,Color.WHITE,true);
        FrameLayout.LayoutParams labelLp = new FrameLayout.LayoutParams(-2,-2);
        labelLp.leftMargin=dp(24); labelLp.topMargin=dp(24); hero.addView(coverLabel,labelLp);
        Button edit = button("Edit Profile", false);
        FrameLayout.LayoutParams editLp = new FrameLayout.LayoutParams(dp(104),dp(48),Gravity.TOP|Gravity.RIGHT);
        editLp.topMargin=dp(12); editLp.rightMargin=dp(16); hero.addView(edit,editLp);
        edit.setOnClickListener(v -> showEdit(true));
        FrameLayout ring = new FrameLayout(this); ring.setPadding(dp(5),dp(5),dp(5),dp(5));
        ring.setBackground(bg(Color.WHITE,100));
        FrameLayout.LayoutParams ringLp = new FrameLayout.LayoutParams(dp(124),dp(124),Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        ringLp.topMargin=dp(100); hero.addView(ring,ringLp);
        ImageView avatar = photo(prefs.getString("photo","")); round(avatar);
        ring.addView(avatar,new FrameLayout.LayoutParams(-1,-1));
        avatar.setOnClickListener(v -> previewPhoto(prefs.getString("photo","")));

        LinearLayout content = column(); content.setPadding(dp(24),0,dp(24),0); page.addView(content);
        centered(content,text(prefs.getString("name","Jhon Lennon"),27,INK,true));
        gap(content,8);
        centered(content,text("@"+prefs.getString("username","jhonlennon"),13,PURPLE,false));
        gap(content,12);
        TextView bio = text(prefs.getString("bio",DEFAULT_BIO),13,MUTED,false);
        bio.setLineSpacing(dp(4),1); centered(content,bio);
        gap(content,22);
        LinearLayout actions = row();
        Button message = button("Pesan",false);
        actions.addView(message,new LinearLayout.LayoutParams(0,dp(48),1));
        message.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Kontak")
            .setMessage(prefs.getString("contact","").isEmpty() ? "Kontak belum ditambahkan. Isi melalui Edit Profil." : prefs.getString("contact",""))
            .setPositiveButton("Tutup",null).show());
        Button follow = button(prefs.getBoolean("follow",false) ? "Mengikuti" : "Follow",true);
        LinearLayout.LayoutParams followLp = new LinearLayout.LayoutParams(0,dp(48),2);
        followLp.setMargins(dp(12),0,dp(12),0); actions.addView(follow,followLp);
        follow.setOnClickListener(v -> {
            boolean on = !prefs.getBoolean("follow",false);
            prefs.edit().putBoolean("follow",on).apply(); showProfile();
        });
        Button share = button("↗",false); share.setContentDescription("Bagikan profil");
        actions.addView(share,new LinearLayout.LayoutParams(dp(48),dp(48)));
        share.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_SEND); i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT,prefs.getString("name","Jhon Lennon")+"\n@"+
                prefs.getString("username","jhonlennon")+"\n"+prefs.getString("bio",DEFAULT_BIO));
            startActivity(Intent.createChooser(i,"Bagikan profil"));
        });
        content.addView(actions); gap(content,26);
        LinearLayout stats = row();
        stat(stats,"205","Posts"); stat(stats,prefs.getBoolean("follow",false) ? "205.001" : "205K","Followers");
        stat(stats,"870","Mengikuti");
        content.addView(stats); gap(content,22);
        View line = new View(this); line.setBackgroundColor(0xffe0f2fe);
        content.addView(line,new LinearLayout.LayoutParams(-1,dp(1))); gap(content,20);
        LinearLayout heading = row();
        heading.addView(text("Followers",15,INK,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView demo = text("Data contoh",11,MUTED,false); heading.addView(demo); content.addView(heading);
        gap(content,15);
        LinearLayout followers = row();
        String[] names = {"Paul","George","Ringo","Yoko","Julian"};
        int[] colors = {0xfffef3c7,0xffe0f2fe,0xffdcfce7,0xffffe4e6,0xffe0e7ff};
        for(int i=0;i<names.length;i++) {
            LinearLayout f = column(); f.setGravity(Gravity.CENTER);
            TextView initial = text(names[i].substring(0,1),19,PURPLE,true);
            initial.setGravity(Gravity.CENTER); initial.setBackground(bg(colors[i],50));
            f.addView(initial,new LinearLayout.LayoutParams(dp(44),dp(44)));
            gap(f,7); f.addView(text(names[i],11,MUTED,false));
            followers.addView(f,new LinearLayout.LayoutParams(0,-2,1));
        }
        content.addView(followers); gap(content,25);
        content.addView(text("Photos",15,INK,true)); gap(content,14);
        LinearLayout gallery = row();
        int[] pictures = {R.drawable.john_lennon, R.drawable.archive_one, R.drawable.archive_two, R.drawable.archive_three};
        for (int resource : pictures) {
            ImageView tile = new ImageView(this);
            tile.setImageResource(resource); tile.setScaleType(ImageView.ScaleType.CENTER_CROP);
            tile.setContentDescription("Foto arsip John Lennon");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,dp(108),1);
            lp.setMargins(dp(2),0,dp(2),0); gallery.addView(tile,lp);
            tile.setOnClickListener(v -> {
                ImageView full = new ImageView(this); full.setImageResource(resource);
                full.setAdjustViewBounds(true);
                new AlertDialog.Builder(this).setTitle("John Lennon").setView(full).setPositiveButton("Tutup",null).show();
            });
        }
        content.addView(gallery); gap(content,16);
        centered(content,text("Profil demo • tersimpan di perangkat",11,MUTED,false));
    }
    private void stat(LinearLayout row, String value, String label) {
        LinearLayout c = column(); centered(c,text(value,21,INK,true));
        gap(c,7); centered(c,text(label,11,MUTED,false));
        row.addView(c,new LinearLayout.LayoutParams(0,-2,1));
    }
    private void previewPhoto(String path) {
        ImageView image = photo(path); image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        new AlertDialog.Builder(this).setTitle("Foto profil").setView(image)
            .setPositiveButton("Tutup",null).show();
    }

    private void showEdit(boolean fresh) {
        editing = true;
        if(fresh) pendingPhoto = prefs.getString("photo","");
        LinearLayout page = page(); page.setPadding(dp(24),dp(10),dp(24),dp(28));
        LinearLayout toolbar = row();
        Button back = button("‹",false); back.setTextSize(28); back.setContentDescription("Kembali");
        toolbar.addView(back,new LinearLayout.LayoutParams(dp(48),dp(48)));
        back.setOnClickListener(v -> confirmBack());
        TextView title = text("Edit Profile",21,INK,true);
        title.setGravity(Gravity.CENTER);
        toolbar.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));
        toolbar.addView(new View(this),new LinearLayout.LayoutParams(dp(48),1));
        page.addView(toolbar); gap(page,24);
        editAvatar = photo(pendingPhoto); round(editAvatar);
        LinearLayout.LayoutParams avatarLp = new LinearLayout.LayoutParams(dp(100),dp(100));
        avatarLp.gravity=Gravity.CENTER_HORIZONTAL; page.addView(editAvatar,avatarLp);
        editAvatar.setOnClickListener(v -> choosePhoto());
        gap(page,6);
        Button change = button("Ubah foto profil",false);
        LinearLayout.LayoutParams changeLp = new LinearLayout.LayoutParams(-2,dp(48));
        changeLp.gravity=Gravity.CENTER_HORIZONTAL; page.addView(change,changeLp);
        change.setOnClickListener(v -> choosePhoto()); gap(page,20);
        nameField = field(page,"Name",prefs.getString("name","Jhon Lennon"),false);
        userField = field(page,"Username",prefs.getString("username","jhonlennon"),false);
        userField.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        bioField = field(page,"Bio",prefs.getString("bio",DEFAULT_BIO),true);
        contactField = field(page,"Contact",prefs.getString("contact",""),false);
        contactField.setHint("Tambahkan email atau nomor telepon");
        page.addView(text("Gender / Pilihan",13,INK,true)); gap(page,8);
        genderField = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,GENDERS);
        genderField.setAdapter(adapter);
        genderField.setSelection(prefs.getInt("gender",0));
        genderField.setBackground(bg(0xfff0f9ff,6));
        page.addView(genderField,new LinearLayout.LayoutParams(-1,dp(52)));
        gap(page,25);
        Button save = button("Save Changes",true);
        page.addView(save,new LinearLayout.LayoutParams(-1,dp(52)));
        save.setOnClickListener(v -> saveProfile());
    }
    private EditText field(LinearLayout page,String label,String value,boolean multiline) {
        page.addView(text(label,13,INK,true)); gap(page,8);
        EditText e = new EditText(this); e.setText(value); e.setTextSize(14); e.setTextColor(INK);
        e.setHintTextColor(MUTED); e.setPadding(dp(14),dp(12),dp(14),dp(12));
        GradientDrawable border = bg(Color.WHITE,6); border.setStroke(dp(1),0xffbae6fd);
        e.setBackground(border);
        e.setSingleLine(!multiline);
        if(multiline) { e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE); e.setMinLines(3); e.setGravity(Gravity.TOP); }
        page.addView(e,new LinearLayout.LayoutParams(-1,multiline ? -2 : dp(52)));
        gap(page,18); return e;
    }
    private void saveProfile() {
        String name = nameField.getText().toString().trim();
        String username = userField.getText().toString().trim().replaceFirst("^@","");
        if(name.isEmpty()) { nameField.setError("Nama wajib diisi"); nameField.requestFocus(); return; }
        if(!username.matches("[A-Za-z0-9_.]{3,30}")) {
            userField.setError("Gunakan 3–30 huruf, angka, titik, atau garis bawah"); userField.requestFocus(); return;
        }
        prefs.edit().putString("name",name).putString("username",username)
            .putString("bio",bioField.getText().toString().trim())
            .putString("contact",contactField.getText().toString().trim())
            .putInt("gender",genderField.getSelectedItemPosition())
            .putString("photo",pendingPhoto).apply();
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE))
            .hideSoftInputFromWindow(root.getWindowToken(),0);
        showProfile();
        Toast.makeText(this,"Perubahan berhasil disimpan",Toast.LENGTH_SHORT).show();
    }
    private void choosePhoto() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        try { startActivityForResult(i,PICK_PHOTO); }
        catch(ActivityNotFoundException e) { Toast.makeText(this,"Pemilih foto tidak tersedia",Toast.LENGTH_SHORT).show(); }
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request!=PICK_PHOTO || result!=RESULT_OK || data==null || data.getData()==null) return;
        Uri uri = data.getData();
        Toast.makeText(this,"Memuat foto…",Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                Bitmap bitmap;
                if(android.os.Build.VERSION.SDK_INT>=28) {
                    ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(),uri);
                    bitmap = ImageDecoder.decodeBitmap(source,(decoder,info,s) -> {
                        int w=info.getSize().getWidth(),h=info.getSize().getHeight();
                        float scale=Math.min(1f,1024f/Math.max(w,h));
                        decoder.setTargetSize(Math.max(1,(int)(w*scale)),Math.max(1,(int)(h*scale)));
                    });
                } else {
                    BitmapFactory.Options opts=new BitmapFactory.Options(); opts.inJustDecodeBounds=true;
                    try(InputStream in=getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in,null,opts); }
                    opts.inSampleSize=1;
                    while(Math.max(opts.outWidth,opts.outHeight)/opts.inSampleSize>1024) opts.inSampleSize*=2;
                    opts.inJustDecodeBounds=false;
                    try(InputStream in=getContentResolver().openInputStream(uri)) { bitmap=BitmapFactory.decodeStream(in,null,opts); }
                }
                if(bitmap==null) throw new IOException("Invalid image");
                File output=File.createTempFile("avatar_",".jpg",getFilesDir());
                try(FileOutputStream stream=new FileOutputStream(output)) { bitmap.compress(Bitmap.CompressFormat.JPEG,90,stream); }
                runOnUiThread(() -> {
                    if(!isFinishing() && editing) { pendingPhoto=output.getAbsolutePath(); loadPhoto(editAvatar,pendingPhoto); }
                });
            } catch(Exception ex) {
                runOnUiThread(() -> Toast.makeText(this,"Foto tidak dapat dibuka. Pilih foto lain.",Toast.LENGTH_LONG).show());
            }
        }).start();
    }
    private void confirmBack() {
        new AlertDialog.Builder(this).setTitle("Keluar dari edit profil?")
            .setMessage("Perubahan yang belum disimpan akan dibatalkan.")
            .setNegativeButton("Lanjut edit",null)
            .setPositiveButton("Keluar",(d,w) -> showProfile()).show();
    }
    @Override public void onBackPressed() { if(editing) confirmBack(); else super.onBackPressed(); }
}
